  <?php get_header(); ?>

  <main class="bg-c-gray-2" id="main">
    <section class="opacity-100 transition-opacity duration-1000">
      <div class="xl:py-c-33 md:py-c-91 sm:py-20 py-14">
        <?php
          $params= array(
            'orderby' => 't.post_title DESC',
            'limit' => 0,
          );
          $news_pod= pods( 'padra_content', $params );
          $items= $news_pod->data();
          foreach( $items as $item ){
            $announcements = pods_field( 'padra_content', $item->ID, 'announcement' );
            foreach( $announcements as $announcement){
              echo '<div class="flex xl:flex-row flex-col xl:items-stretch items-center xl:px-c-33 xl:not-last-child:mb-c-37 md:not-last-child:mb-c-90 not-last-child:mb-c-56 xl:gap-0 md:gap-4 gap-2">
                <div class="xl:w-c-27 xl:h-c-27 md:w-c-93 md:h-c-93 w-c-76 h-c-76 bg-cover bg-center bg-no-repeat" style="background-image: url(' . wp_get_attachment_url($announcement['news_image']) . ');">
                </div>
                <div class="xl:flex-1 xl:pl-c-17 xl:pt-c-14 xl:w-unset lg:w-c-94 md:w-c-77 w-c-60">
                  <div class="xl:text-c-13 md:text-c-31 text-c-32 xl:mb-c-5 md:mb-3 mb-c-89 xl:leading-c-2 md:leading-c-17 leading-c-18 xl:tracking-c-7 md:tracking-c-24 tracking-c-25 w-c-38 xl:mx-unset mx-auto xl:text-left text-center">'
                    . $announcement['news_title'] .
                  '</div>
                  <p class="xl:text-c-6 md:text-c-19 text-c-21 xl:leading-c-6 md:leading-c-14 leading-c-15 xl:tracking-c-3 md:tracking-c-12 tracking-c-14 xl:indent-c-14 md:indent-c-36 indent-c-58 text-justify">'
                    . $announcement['news_text'] .
                  '</p>
                </div>
              </div>';
            }
          }
	      ?>
      </div>
    </section>

    <section class="opacity-0 transition-opacity duration-1000">
      <div class="xl:pt-c-34 md:pt-c-56 pt-16 xl:pb-c-13 md:pb-c-57 pb-20 hidden">
        <div class="text-center xl:text-c-4 md:text-c-20 text-c-23 xl:mb-c-19 md:mb-c-55 mb-14">
          <span class="relative xl:bottom-c-5 xl:left-c-22 md:bottom-4 md:left-c-58 bottom-3 left-4">M</span><span class="xl:tracking-c-4 md:tracking-c-13 tracking-c-18">usic</span>
        </div>
        <?php
          $params= array(
            'orderby' => 't.post_title DESC',
            'limit' => 0,
          );
          $music_pod= pods( 'padra_content', $params );
          $items= $music_pod->data();
          foreach($items as $item){
            $musics = pods_field( 'padra_content', $item->ID, 'album_single_track' );
            foreach($musics as $music){
              if($music['album_or_single_track'] && !$music['instrumental_or_with_lyrics']){
                echo '<article class="lyrics-having-album flex xl:flex-row flex-col xl:justify-center xl:items-stretch items-center xl:not-last-child:mb-c-13 md:not-last-child:mb-c-57 not-last-child:mb-20">
                  <div class="xl:w-2/6 md:w-c-40 sm:w-80 w-60">
                    <div class="w-full sticky top-0">
                      <img class="w-full h-auto" src="' . wp_get_attachment_image_url( $music['music_image'], 'full' ) . '" alt="' . get_post_meta( $music['music_image'], '_wp_attachment_image_alt', true ) . '">'
                        . $music['spotify_player'] .
                      '<button class="toggle-btn flex flex-col items-center absolute bottom-0 group transition-opacity duration-500 opacity-100 xl:left-c-28 md:left-c-48 left-c-63 xl:gap-c-5 md:gap-c-46 gap-c-62 -translate-x-1/2 focus:outline-none">
                        <div class="[writing-mode:vertical-lr] [text-orientation:upright] group-hover:text-shadow-c duration-200 xl:text-c-7 md:text-c-18 text-c-19 xl:-tracking-c-5 md:-tracking-c-11 -tracking-c-17">Lyrics</div>
                        <svg class="fill-gray-300 group-hover:drop-shadow-c transition-c-6 duration-200 xl:w-c-29 md:w-c-49 w-c-61" xmlns="http://www.w3.org/2000/svg" viewBox="3 6 19 14"><path d="M0 0h24v24H0z" fill="none"></path><path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"></path></svg>
                        <svg class="fill-gray-300 group-hover:drop-shadow-c transition-c-6 duration-200 xl:w-c-29 md:w-c-49 w-c-61 hidden" xmlns="http://www.w3.org/2000/svg" viewBox="1 1 22 22"><path d="M13 7.5a1 1 0 11-2 0 1 1 0 012 0zm-3 3.75a.75.75 0 01.75-.75h1.5a.75.75 0 01.75.75v4.25h.75a.75.75 0 010 1.5h-3a.75.75 0 010-1.5h.75V12h-.75a.75.75 0 01-.75-.75z"></path><path fill-rule="evenodd" d="M12 1C5.925 1 1 5.925 1 12s4.925 11 11 11 11-4.925 11-11S18.075 1 12 1zM2.5 12a9.5 9.5 0 1119 0 9.5 9.5 0 01-19 0z"></path></svg>
                      </button>
                    </div>
                  </div>
                  <div class="xl:w-3/6 md:w-c-41 w-c-60 xl:pl-c">
                    <div class="xl:text-c-5 md:text-c-15 text-c-22 xl:text-left text-center xl:mt-0 md:mt-6 mt-c-59">
                      <h1 class="italic xl:tracking-c md:tracking-c-9 tracking-c-15 text-shadow-c-2">
                        <strong>' . $music['album_single_track_name'] . '</strong>
                      </h1>
                      <div class="xl:my-c-15 md:my-c-47 my-3 xl:tracking-c-2 md:tracking-c-10 tracking-c-16 text-gray-400">
                        Release Date:
                      </div>
                      <div class="italic xl:tracking-c md:tracking-c-9 tracking-c-15 text-shadow-c-2">'
                        . $music['release_date'] .
                      '</div>
                    </div>
                    <div class="dual-cnt xl:pl-c-22 transition-opacity duration-500 opacity-100">
                      <p class="text-gray-200 xl:pt-c-21 md:pt-3 pt-c-43 xl:text-c-6 md:text-c-19 text-c-21 xl:leading-c-3 md:leading-c-10 leading-c-11 xl:tracking-c-3 md:tracking-c-12 tracking-c-14">'
                        . $music['music_info'] .
                      '</p>
                      <div class="xl:pt-c-14 md:pt-6 sm:pt-c-59 sm:mt-0 -mt-c-72 hidden">
                        <div class="track-list-cnt sm:w-1/3 xl:text-c-8 md:text-c-17 text-c-25">
                          <div class="track-list sticky top-0">
                            <div class="xl:py-c-11 md:py-2 py-c-72 md:w-c-4 w-c-70 sm:ml-auto xl:mr-c-24 md:mr-c-52 sm:mr-c-71">
                              <svg class="fill-gray-300 w-full h-auto" xmlns="http://www.w3.org/2000/svg" viewBox="3 6 19 14"><path d="M0 0h24v24H0z" fill="none"></path><path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"></path></svg>
                            </div>
                            <div class="text-gray-200 border-t sm:border-b border-l sm:border-r-0 border-r border-c-gray-7">';
                              $lha_counter= 0;
                              foreach($music['track_lyrics_translation'] as $details){
                                if($details['an_instrumental_track_from_a_lyrics_having_album']){
                                  $lha_counter++;
                                  echo '<div class="cursor-default not-last-child:border-b not-last-child:border-c-gray-7 track-name xl:px-c-11 xl:py-c-10 md:px-c-51 md:py-c-50 px-c-69 py-c-68 w-full text-left text-gray-600 font-bold" title="Instrumental">'
                                    . $lha_counter . '. ' . $details['track_name'] .
                                  '</div>';
                                }
                                else{
                                  $lha_counter++;
                                  echo '<button class="not-last-child:border-b not-last-child:border-c-gray-7 track-name xl:px-c-11 xl:py-c-10 md:px-c-51 md:py-c-50 px-c-69 py-c-68 w-full text-left hover:bg-c-gray-3 transition-colors focus:outline-none">'
                                    . $lha_counter . '. ' . $details['track_name'] .
                                  '</button>';
                                }
                              }
                            echo '</div>
                          </div>
                        </div>
                        <div class="lyrics-cnt sm:flex-1 overflow-hidden xl:pt-c-5 xl:pb-c-15 md:pt-c-46 md:pb-c-47 pt-c-62 pb-3 border border-c-gray-7 sm:rounded-tr rounded-br sm:rounded-bl-none rounded-bl">';
                        foreach($music['track_lyrics_translation'] as $details){
                          if(!$details['an_instrumental_track_from_a_lyrics_having_album']){
                            echo '<div class="lyrics transition-opacity duration-500 opacity-0">';
                            foreach($details['sub_lyrics_clone'] as $sub_lyrics){
                              echo '<div class="sub-lyrics hidden xl:not-last-child:mb-c-21 md:not-last-child:mb-c-53 not-last-child:mb-5">
                              <div class="sub-lyrics-fa [direction:rtl] xl:text-c-5 md:text-c-15 text-c-22 xl:[word-spacing:.2vw] md:[word-spacing:.135rem] [word-spacing:.125rem] text-c-gray-5 w-3/4 ml-auto xl:mr-c-22 md:mr-c-42 mr-c-64 xl:mb-c-23 md:mb-c-44 mb-c-66 font-Badkhat2">';
                                foreach($sub_lyrics['farsi_sub_lyrics_clone'] as $farsi_sub_lyrics){
                                  echo '<p class="xl:not-last-child:mb-c-25 md:not-last-child:mb-c-43 not-last-child:mb-c-65 xl:leading-c-5 md:leading-c-8 leading-c-12">'
                                    . $farsi_sub_lyrics['farsi_lyrics'] .
                                 '</p>';
                                }
                              echo '</div>
                              <div class="sub-lyrics-en xl:text-c-9 md:text-c-16 text-c-24 xl:[word-spacing:.25vw] md:[word-spacing:.17rem] [word-spacing:.15rem] xl:tracking-c-5 md:tracking-c-8 tracking-c-17 text-white w-3/4 mr-auto xl:ml-c-22 md:ml-c-42 ml-c-64">';
                              foreach($sub_lyrics['english_sub_lyrics_clone'] as $english_sub_lyrics){
                                echo '<p class="xl:not-last-child:mb-c-25 md:not-last-child:mb-c-43 not-last-child:mb-c-65 xl:leading-c-5 md:leading-c-8 leading-c-12">'
                                  . $english_sub_lyrics['english_lyrics'] .
                                '</p>';
                              }
                              echo '</div>
                              </div>';
                            }
                            echo '</div>';
                          }
                        }
                        echo
                        '</div>
                      </div>
                    </div>
                  </div>
                </article>';
              }

              if($music['album_or_single_track'] && $music['instrumental_or_with_lyrics']){
                echo '<article class="instrumental-album flex xl:flex-row flex-col xl:justify-center xl:items-stretch items-center xl:not-last-child:mb-c-13 md:not-last-child:mb-c-57 not-last-child:mb-20">
                  <div class="xl:w-2/6 md:w-c-40 sm:w-80 w-60">
                    <div class="w-full sticky top-0">
                      <img class="w-full h-auto" src="' . wp_get_attachment_image_url( $music['music_image'], 'full' ) . '" alt="' . get_post_meta( $music['music_image'], '_wp_attachment_image_alt', true ) . '">'
                        . $music['spotify_player'] .
                      '<button class="toggle-btn flex flex-col items-center absolute bottom-0 group transition-opacity duration-500 opacity-100 xl:left-c-28 md:left-c-48 left-c-63 xl:gap-c-5 md:gap-c-46 gap-c-62 -translate-x-1/2 focus:outline-none">
                        <div class="[writing-mode:vertical-lr] [text-orientation:upright] group-hover:text-shadow-c duration-200 xl:text-c-7 md:text-c-18 text-c-19 xl:-tracking-c-5 md:-tracking-c-11 -tracking-c-17">Tracklist</div>
                        <svg class="fill-gray-300 group-hover:drop-shadow-c transition-c-6 duration-200 xl:w-c-29 md:w-c-49 w-c-61" xmlns="http://www.w3.org/2000/svg" viewBox="3 6 19 14"><path d="M0 0h24v24H0z" fill="none"></path><path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"></path></svg>
                        <svg class="fill-gray-300 group-hover:drop-shadow-c transition-c-6 duration-200 xl:w-c-29 md:w-c-49 w-c-61 hidden" xmlns="http://www.w3.org/2000/svg" viewBox="1 1 22 22"><path d="M13 7.5a1 1 0 11-2 0 1 1 0 012 0zm-3 3.75a.75.75 0 01.75-.75h1.5a.75.75 0 01.75.75v4.25h.75a.75.75 0 010 1.5h-3a.75.75 0 010-1.5h.75V12h-.75a.75.75 0 01-.75-.75z"></path><path fill-rule="evenodd" d="M12 1C5.925 1 1 5.925 1 12s4.925 11 11 11 11-4.925 11-11S18.075 1 12 1zM2.5 12a9.5 9.5 0 1119 0 9.5 9.5 0 01-19 0z"></path></svg>
                      </button>
                    </div>
                  </div>
                  <div class="xl:w-3/6 md:w-c-41 w-c-60 xl:pl-c">
                    <div class="xl:text-c-5 md:text-c-15 text-c-22 xl:text-left text-center xl:mt-0 md:mt-6 mt-c-59">
                      <h1 class="italic xl:tracking-c md:tracking-c-9 tracking-c-15 text-shadow-c-2">
                        <strong>' . $music['album_single_track_name'] . '</strong>
                      </h1>
                      <div class="xl:my-c-15 md:my-c-47 my-3 xl:tracking-c-2 md:tracking-c-10 tracking-c-16 text-gray-400">
                        Release Date:
                      </div>
                      <div class="italic xl:tracking-c md:tracking-c-9 tracking-c-15 text-shadow-c-2">'
                        . $music['release_date'] .
                      '</div>
                    </div>
                    <div class="dual-cnt xl:pl-c-22 transition-opacity duration-500 opacity-100">
                      <p class="text-gray-200 xl:pt-c-21 md:pt-3 pt-c-43 xl:text-c-6 md:text-c-19 text-c-21 xl:leading-c-3 md:leading-c-10 leading-c-11 xl:tracking-c-3 md:tracking-c-12 tracking-c-14">'
                        . $music['music_info'] .
                      '</p>
                      <div class="xl:pt-c-14 pt-0 hidden">
                        <div class="track-list-cnt xl:text-c-8 md:text-c-17 text-c-25">
                          <div class="track-list xl:mt-0 md:-mt-2 -mt-c-72 xl:w-unset xl:mx-unset w-c-38 mx-auto">
                            <div class="xl:py-c-11 md:py-2 py-c-72 xl:w-1/3">
                              <svg class="fill-gray-300 xl:w-c-4 md:w-4 w-c-70 h-auto" xmlns="http://www.w3.org/2000/svg" viewBox="3 6 19 14"><path d="M0 0h24v24H0z" fill="none"></path><path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"></path></svg>
                            </div>
                            <div class="border border-c-gray-7 text-gray-300 xl:w-3/4">';
                            $ia_counter= 0;
                            foreach($music['track_lyrics_translation'] as $details){
                              $ia_counter++;
                              echo '<div class="cursor-default not-last-child:border-b not-last-child:border-c-gray-7 xl:px-c-11 xl:py-c-10 md:px-c-51 md:py-c-50 px-c-69 py-c-68">'
                                . $ia_counter . '. ' . $details['track_name'] .
                              '</div>';
                            }
                            echo
                            '</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </article>';
              }

              if(!$music['album_or_single_track'] && !$music['instrumental_or_with_lyrics']){
                echo '<article class="lyrics-having-single flex xl:flex-row flex-col xl:justify-center xl:items-stretch items-center xl:not-last-child:mb-c-13 md:not-last-child:mb-c-57 not-last-child:mb-20">
                  <div class="xl:w-2/6 md:w-c-40 sm:w-80 w-60">
                    <div class="w-full sticky top-0">
                      <img class="w-full h-auto" src="' . wp_get_attachment_image_url( $music['music_image'], 'full' ) . '" alt="' . get_post_meta( $music['music_image'], '_wp_attachment_image_alt', true ) . '">'
                        . $music['spotify_player'] .
                      '<button class="toggle-btn flex flex-col items-center absolute bottom-0 group transition-opacity duration-500 opacity-100 xl:left-c-28 md:left-c-48 left-c-63 xl:gap-c-5 md:gap-c-46 gap-c-62 -translate-x-1/2 focus:outline-none">
                        <div class="[writing-mode:vertical-lr] [text-orientation:upright] group-hover:text-shadow-c duration-200 xl:text-c-7 md:text-c-18 text-c-19 xl:-tracking-c-5 md:-tracking-c-11 -tracking-c-17">Lyrics</div>
                        <svg class="fill-gray-300 group-hover:drop-shadow-c transition-c-6 duration-200 xl:w-c-29 md:w-c-49 w-c-61" xmlns="http://www.w3.org/2000/svg" viewBox="3 6 19 14"><path d="M0 0h24v24H0z" fill="none"></path><path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"></path></svg>
                        <svg class="fill-gray-300 group-hover:drop-shadow-c transition-c-6 duration-200 xl:w-c-29 md:w-c-49 w-c-61 hidden" xmlns="http://www.w3.org/2000/svg" viewBox="1 1 22 22"><path d="M13 7.5a1 1 0 11-2 0 1 1 0 012 0zm-3 3.75a.75.75 0 01.75-.75h1.5a.75.75 0 01.75.75v4.25h.75a.75.75 0 010 1.5h-3a.75.75 0 010-1.5h.75V12h-.75a.75.75 0 01-.75-.75z"></path><path fill-rule="evenodd" d="M12 1C5.925 1 1 5.925 1 12s4.925 11 11 11 11-4.925 11-11S18.075 1 12 1zM2.5 12a9.5 9.5 0 1119 0 9.5 9.5 0 01-19 0z"></path></svg>
                      </button>
                    </div>
                  </div>
                  <div class="xl:w-3/6 md:w-c-41 w-c-60 xl:pl-c">
                    <div class="xl:text-c-5 md:text-c-15 text-c-22 xl:text-left text-center xl:mt-0 md:mt-6 mt-c-59">
                      <h1 class="italic xl:tracking-c md:tracking-c-9 tracking-c-15 text-shadow-c-2">
                        <strong>' . $music['album_single_track_name'] . '</strong>
                      </h1>
                      <div class="xl:my-c-15 md:my-c-47 my-3 xl:tracking-c-2 md:tracking-c-10 tracking-c-16 text-gray-400">
                        Release Date:
                      </div>
                      <div class="italic xl:tracking-c md:tracking-c-9 tracking-c-15 text-shadow-c-2">'
                        . $music['release_date'] .
                      '</div>
                    </div>
                    <div class="dual-cnt xl:pl-c-22 transition-opacity duration-500 opacity-100">
                      <p class="text-gray-200 xl:pt-c-21 md:pt-3 pt-c-43 xl:text-c-6 md:text-c-19 text-c-21 xl:leading-c-3 md:leading-c-10 leading-c-11 xl:tracking-c-3 md:tracking-c-12 tracking-c-14">'
                        . $music['music_info'] .
                      '</p>
                      <div class="xl:pt-c-14 md:pt-8 pt-7 hidden">
                        <div class="lyrics-cnt">
                          <div class="lyrics">';
                          foreach($music['track_lyrics_translation'] as $details){
                            foreach($details['sub_lyrics_clone'] as $sub_lyrics){
                              echo '<div class="sub-lyrics xl:not-last-child:mb-c-21 md:not-last-child:mb-c-53 not-last-child:mb-5">
                                <div class="sub-lyrics-fa [direction:rtl] xl:text-c-5 md:text-c-15 text-c-22 xl:[word-spacing:.2vw] md:[word-spacing:.135rem] [word-spacing:.125rem] text-c-gray-5 border-r [border-image:linear-gradient(to_bottom,rgba(0,0,0,0),#4a4a4a,rgba(0,0,0,0))_1_100%] w-3/4 ml-auto pr-c-14 xl:mb-c-23 md:mb-c-44 mb-c-66 font-Badkhat2 rounded-tr-lg">';
                                foreach($sub_lyrics['farsi_sub_lyrics_clone'] as $farsi_sub_lyrics){
                                  echo '<p class="xl:not-last-child:mb-c-25 md:not-last-child:mb-c-43 not-last-child:mb-c-65 xl:leading-c-5 md:leading-c-8 leading-c-12">'
                                    . $farsi_sub_lyrics['farsi_lyrics'] .
                                  '</p>';
                                }
                                echo '</div>
                                <div class="sub-lyrics-en xl:text-c-9 md:text-c-16 text-c-24 xl:[word-spacing:.25vw] md:[word-spacing:.17rem] [word-spacing:.15rem] xl:tracking-c-5 md:tracking-c-8 tracking-c-17 text-white border-l [border-image:linear-gradient(to_bottom,rgba(0,0,0,0),#4a4a4a,rgba(0,0,0,0))_1_100%] w-3/4 mr-auto pl-c-14 rounded-bl-lg">';
                                foreach($sub_lyrics['english_sub_lyrics_clone'] as $english_sub_lyrics){
                                  echo '<p class="xl:not-last-child:mb-c-2 md:not-last-child:mb-c-45 not-last-child:mb-c-67 xl:leading-c-4 md:leading-c-9 leading-c-13">'
                                    . $english_sub_lyrics['english_lyrics'] .
                                  '</p>';
                                }
                              echo '</div>
                              </div>';
                            }
                          }
                          echo
                          '</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </article>';
              }

              if(!$music['album_or_single_track'] && $music['instrumental_or_with_lyrics']){
                echo '<article class="instrumental-single flex xl:flex-row flex-col xl:justify-center xl:items-stretch items-center xl:not-last-child:mb-c-13 md:not-last-child:mb-c-57 not-last-child:mb-20">
                  <div class="xl:w-2/6 md:w-c-40 sm:w-80 w-60">
                    <div class="w-full sticky top-0">
                      <img class="w-full h-auto" src="' . wp_get_attachment_image_url( $music['music_image'], 'full' ) . '" alt="' . get_post_meta( $music['music_image'], '_wp_attachment_image_alt', true ) . '">'
                        . $music['spotify_player'] .
                    '</div>
                  </div>
                  <div class="xl:w-3/6 md:w-c-41 w-c-60 xl:pl-c">
                    <div class="xl:text-c-5 md:text-c-15 text-c-22 xl:text-left text-center xl:mt-0 md:mt-6 mt-c-59">
                      <h1 class="italic xl:tracking-c md:tracking-c-9 tracking-c-15 text-shadow-c-2">
                        <strong>' . $music['album_single_track_name'] . '</strong>
                      </h1>
                      <div class="xl:my-c-15 md:my-c-47 my-3 xl:tracking-c-2 md:tracking-c-10 tracking-c-16 text-gray-400">
                        Release Date:
                      </div>
                      <div class="italic xl:tracking-c md:tracking-c-9 tracking-c-15 text-shadow-c-2">'
                        . $music['release_date'] .
                      '</div>
                    </div>
                    <div class="xl:pl-c-22 transition-opacity duration-500 opacity-100">
                      <p class="text-gray-200 xl:pt-c-21 md:pt-3 pt-c-43 xl:text-c-6 md:text-c-19 text-c-21 xl:leading-c-3 md:leading-c-10 leading-c-11 xl:tracking-c-3 md:tracking-c-12 tracking-c-14">'
                        . $music['music_info'] .
                      '</p>
                    </div>
                  </div>
                </article>';
              }
            }
          }
        ?>
      </div>
    </section>

    <section class="opacity-0 transition-opacity duration-1000">
      <div class="xl:pt-c-34 xl:pb-c-18 md:pt-c-87 md:pb-20 pt-c-88 pb-c-56 hidden">
        <div class="text-center xl:text-c-4 md:text-c-20 text-c-23 xl:mb-c-26 md:mb-c-87 mb-c-88">
          Band
        </div>
        <?php
          $params= array(
            'orderby' => 't.post_title DESC',
            'limit' => 0,
          );
          $artist_pod= pods( 'padra_content', $params );
          $items= $artist_pod->data();
          foreach( $items as $item ){
            $artists = pods_field( 'padra_content', $item->ID, 'artist' );
            foreach( $artists as $artist){
              echo '<div class="flex xl:flex-row flex-col-reverse xl:items-stretch items-center xl:not-last-child:mb-c-18 md:not-last-child:mb-20 not-last-child:mb-c-56 xl:px-c-16 xl:gap-0 md:gap-8 gap-6">
                <div class="xl:flex-1 xl:py-c-17 xl:pr-c-19 xl:w-unset lg:w-c-78 md:w-c-77 w-c-84 xl:gap-0 md:gap-10 gap-8">
                  <div>
                    <div class="flex xs:justify-start justify-center">
                      <h1 class="xl:text-c-10 md:text-c-26 text-c-27 xl:[word-spacing:.25vw] md:[word-spacing:.1725rem] [word-spacing:.15rem] xl:tracking-c md:tracking-c-19 tracking-c-15 first-letter:font-bold first-letter:border-0 first-letter:border-b-2 first-letter:border-gray-300 first-letter:border-dotted">'
                        . $artist['artists_name'] .
                      '</h1>
                      <div class="flex-1 xs:flex hidden items-center xl:pl-c-11 md:pl-c-79 pl-c-72">
                        <div class="xl:w-c-33 xl:h-c-30 lg:w-24 md:w-20 w-16 h-1 border-y border-gray-300 [border-image:linear-gradient(to_right,#787878,rgba(0,0,0,0))_1_0%]">
                        </div>
                      </div>
                    </div>
                    <h2 class="xl:mt-c-22 xl:ml-c-22 xl:mb-c-15 md:mt-c-54 md:ml-c-54 md:mb-c-73 mt-c-64 xs:ml-c-64 mb-3 italic xl:text-c-7 md:text-c-28 text-c-19 xl:[word-spacing:.125vw] md:[word-spacing:.08625rem] [word-spacing:.075rem] xl:tracking-c-2 md:tracking-c-20 tracking-c-16 xs:text-left text-center">'
                      . $artist['artists_role'] .
                    '</h2>
                    <div class="xl:ml-c-14 md:ml-c-74 xs:ml-c-49 xl:text-c-8 md:text-c-17 text-c-25 xs:text-left text-center">
                      <span class="xl:mr-c-10 md:mr-c-75 mr-c-68 text-gray-300">Born:</span>
                      <span>' . $artist['artists_birthday'] . '</span>
                    </div>
                  </div>
                </div>
                <div class="xl:w-c-31 xl:h-c-31 md:w-c-76 md:h-c-76 w-60 h-60 bg-cover bg-center bg-no-repeat relative" style="background-image: url(' . wp_get_attachment_url($artist['artists_image']) . ');">';
                if($artist['artists_instagram_page_link']){
                  echo '
                  <a class="absolute xl:w-c-22 xl:right-c-32 xl:bottom-c-11 xl:top-unset md:w-c-54 md:right-c-82 md:top-c-79 w-c-64 right-c-83 top-c-72" target="_blank" href="' . $artist['artists_instagram_page_link'] . '">
                    <svg class="fill-gray-300 hover:drop-shadow-c-2 transition-c-6 duration-200 w-full h-auto" xmlns="http://www.w3.org/2000/svg" role="img" viewBox="0 0 24 24"><title></title><path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"></path></svg>
                  </a>';
                }
                echo '<div class="absolute inset-y-0 left-full xl:w-c-17 md:w-c-80 w-c-81 flex justify-center items-center">
                    <div class="whitespace-nowrap rotate-90 xl:text-c-8 md:text-c-17 text-c-25">
                      <span class="xl:tracking-c-5 md:tracking-c-21 tracking-c-17">Photo By:</span>
                      <span class="font-bold xl:tracking-c-2 md:tracking-c-20 tracking-c-16">'
                        . $artist['who_took_the_picture'] .
                      '</span>
                    </div>
                  </div>
                </div>
              </div>';
            }
          }
	      ?>
      </div>
    </section>
  </main>

  <?php get_footer(); ?>