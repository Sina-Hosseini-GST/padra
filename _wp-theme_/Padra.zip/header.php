<!DOCTYPE html>
<html lang="en" class="h-c-95">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo pods( 'padra_content' )->find()->display( 'browser_title' ); ?></title>
  <?php wp_head(); ?>
  
  <!-- Designed and developed by Sina Hosseini -->
</head>
<body class="font-PoiretOne text-white min-h-c-4">

  <div class="h-screen flex flex-col">
    <div class="bg-cover bg-center bg-no-repeat relative flex-1" style="background-image: url(' <?php echo pods( 'padra_content' )->find()->display( 'header_image' ); ?> ');">
      <div class="absolute top-1/2 inset-x-0 translate-x-0 -translate-y-1/2 border-t border-b border-gray-600 text-center xl:text-c-2 md:text-c text-c-3 bg-c-gray flex justify-center xl:py-c-15 md:py-c-70 py-c-6">
        <span class="xl:w-c-3 md:w-c-7 w-4/5 xl:leading-c md:leading-c-7 leading-c-16">
          <?php echo pods( 'padra_content' )->find()->display( 'header_title' ); ?>
        </span>
      </div>
    </div>
    <header class="border-gray-500 border-y h-c-9 xl:min-h-c md:min-h-c-2 min-h-c-3 bg-gradient-to-b from-[#171717] to-[#030303]">
      <nav class="h-full">
        <ul class="h-full flex justify-center font-bold text-c-gray-6 xl:tracking-c-6 md:tracking-c-22 tracking-c-23 xl:text-c-8 md:text-c-19 text-c-14">
          <li>
            <a class="menu-btn inline-flex h-full items-center hover:text-white transition-colors duration-300 xl:px-c-20 md:px-6 px-c-8" href="#main">
              News
            </a>
          </li>
          <li>
            <a class="menu-btn inline-flex h-full items-center hover:text-white transition-colors duration-300 xl:px-c-20 md:px-6 px-c-8" href="#main">
              Music
            </a>
          </li>
          <li>
            <a class="menu-btn inline-flex h-full items-center hover:text-white transition-colors duration-300 xl:px-c-20 md:px-6 px-c-8" href="#main">
              Band
            </a>
          </li>
        </ul>
      </nav>
    </header>
  </div>