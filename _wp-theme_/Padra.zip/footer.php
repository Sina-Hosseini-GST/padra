  <footer class="border-gray-500 border-t xl:h-c-17 md:h-c-35 h-9 bg-black shadow-c-2">
    <ul class="h-full flex justify-center items-center xl:gap-c-14 md:gap-c-36 gap-c-58">
      <?php
        $params= array(
          'orderby' => 't.post_title DESC',
          'limit' => 0,
        );
        $media_link_pod= pods( 'padra_content', $params );
        $items= $media_link_pod->data();
        foreach( $items as $item ){
          $media_links = pods_field( 'padra_content', $item->ID, 'media_link' );
          foreach( $media_links as $media_link){
            echo '<li>
              <a href="' . $media_link['link'] . '" target="_blank">'
                . $media_link['icon'] .
              '</a>
            </li>';
          }
        }
      ?>
    </ul>
  </footer>
  <?php wp_footer(); ?>
  <script>
    var defaultDuration= 1000 // ms
    var edgeOffset= 0 // px
    zenscroll.setup(defaultDuration, edgeOffset)
  </script>
</body>
</html>